# Create your views here.
from django.shortcuts import render, HttpResponse
from django.contrib import messages
from .forms import UserRegistrationForm
from .models import UserRegistrationModel
from django.conf import settings
from django.core.files.storage import FileSystemStorage


# Create your views here.
def UserRegisterActions(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            print('Data is Valid')
            form.save()
            messages.success(request, 'You have been successfully registered')
            form = UserRegistrationForm()
            return render(request, 'UserRegistrations.html', {'form': form})
        else:
            messages.success(request, 'Email or Mobile Already Existed')
            print("Invalid form")
    else:
        form = UserRegistrationForm()
    return render(request, 'UserRegistrations.html', {'form': form})


def UserLoginCheck(request):
    if request.method == "POST":
        loginid = request.POST.get('loginid')
        pswd = request.POST.get('pswd')
        print("Login ID = ", loginid, ' Password = ', pswd)
        try:
            check = UserRegistrationModel.objects.get(loginid=loginid, password=pswd)
            status = check.status
            print('Status is = ', status)
            if status == "activated":
                request.session['id'] = check.id
                request.session['loggeduser'] = check.name
                request.session['loginid'] = loginid
                request.session['email'] = check.email
                print("User id At", check.id, status)
                return render(request, 'users/UserHomePage.html', {})
            else:
                messages.success(request, 'Your Account Not at activated')
                return render(request, 'UserLogin.html')
        except Exception as e:
            print('Exception is ', str(e))
            pass
        messages.success(request, 'Invalid Login id and password')
    return render(request, 'UserLogin.html', {})


def UserHome(request):
    return render(request, 'users/UserHomePage.html', {})


def DatasetView(request):
    return render(request, 'users/viewdataset.html', {})


def UserClassification(request):
    import pandas as pd
    from .utility import Abnormal_Classification
    rf_report = Abnormal_Classification.process_randomForest()
    dt_report = Abnormal_Classification.process_decesionTree()
    knn_report = Abnormal_Classification.process_knn()
    ksvm_report = Abnormal_Classification.process_ksvm()
    lsvm_report = Abnormal_Classification.process_lsvm()
    rf_report = pd.DataFrame(rf_report).transpose()
    rf_report = pd.DataFrame(rf_report)
    dt_report = pd.DataFrame(dt_report).transpose()
    dt_report = pd.DataFrame(dt_report)
    knn_report = pd.DataFrame(knn_report).transpose()
    knn_report = pd.DataFrame(knn_report)
    ksvm_report = pd.DataFrame(ksvm_report).transpose()
    ksvm_report = pd.DataFrame(ksvm_report)
    lsvm_report = pd.DataFrame(lsvm_report).transpose()
    lsvm_report = pd.DataFrame(lsvm_report)
    # report_df.to_csv("rf_report.csv")
    return render(request, 'users/cl_reports.html',
                  {'rf': rf_report.to_html, 'dt': dt_report.to_html, 'knn': knn_report.to_html,
                   'ksvm': ksvm_report.to_html, 'lsvm': lsvm_report.to_html})


def UserPredictions(request):
    if request.method == 'POST':
        image_file = request.FILES['file']
        # let's check if it is a csv file
        # if not image_file.name.endswith('.png'):
        #     messages.error(request, 'THIS IS NOT A PNG  FILE')
        fs = FileSystemStorage(location="media/endusertest/")
        filename = fs.save(image_file.name, image_file)
        # detect_filename = fs.save(image_file.name, image_file)
        uploaded_file_url = "/media/endusertest/" + filename  # fs.url(filename)
        print("Image path ", uploaded_file_url)
        from .utility.predections import predict_user_input
        result = predict_user_input(filename)
        print("Result=", result)
        return render(request, "users/UploadForm.html", {'path': uploaded_file_url, 'result': result})
    else:
        return render(request, "users/UploadForm.html", {})

import cv2
import numpy as np
import os
import pickle
from django.http import StreamingHttpResponse
from django.conf import settings
from skimage.transform import resize
from skimage.io import imread


# Load the trained model
model_path = os.path.join(settings.MEDIA_ROOT, 'model', 'abnormal_detection.alex')
with open(model_path, 'rb') as f:
    clf = pickle.load(f)


def load_frame(frame):
    """Preprocesses a webcam frame for prediction"""
    dimension = (104, 104, 3)
    frame_resized = resize(frame, dimension, anti_aliasing=True, mode='reflect')
    return frame_resized.flatten().reshape(1, -1)


def gen_frames():
    """Captures video from webcam and sends frames"""
    cap = cv2.VideoCapture(0)
    
    while True:
        success, frame = cap.read()
        if not success:
            break
        else:
            # Convert frame to RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img_data = load_frame(frame_rgb)

            # Predict the behavior
            known_classes = ['smoking detected', 'normal detected', 'calling detected']
            probabilities = clf.predict_proba(img_data)
            max_prob = np.max(probabilities)
            threshold = 0.5  # Adjust as needed

            if max_prob < threshold:
                prediction = "Unknown Activity"
            else:
                predicted_class = clf.predict(img_data)[0]
                prediction = known_classes[predicted_class]

            # Overlay Prediction on Frame
            cv2.putText(frame, f"Prediction: {prediction}", (10, 50),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

            # Convert frame to JPEG
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()

            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()
    cv2.destroyAllWindows()


def webcam_feed(request):
    """Returns the video stream"""
    return StreamingHttpResponse(gen_frames(), content_type='multipart/x-mixed-replace; boundary=frame')
from django.http import JsonResponse

def live_prediction(request):
    if request.method == "GET":
        response_data = {
            "message": "Live Prediction is working!",
            "status": "success"
        }
        return JsonResponse(response_data)
    else:
        return JsonResponse({"error": "Invalid request method"}, status=400)
